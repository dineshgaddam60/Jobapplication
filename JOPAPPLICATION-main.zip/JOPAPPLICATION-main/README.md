# Job Connect
Online job application portal
![image](https://github.com/user-attachments/assets/16732ec4-80d1-42d1-be44-0d6566052243)
